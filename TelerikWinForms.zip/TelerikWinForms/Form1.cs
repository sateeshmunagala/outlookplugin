﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.WinControls;
using Telerik.WinControls.UI;

namespace TelerikWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            RadButton btn = new RadButton();
            //txtBox = new TextBox();
            btn.Location = new Point(10, 50);
            btn.Text = "Save";
            btn.Visible = true;
            Controls.Add(btn);
        }
    }
}
