﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OutlookAddIn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            DataTable dt = new DataTable();
            dt.Columns.Add("Feed");

            dt.Rows.Add("Test");
            dt.Rows.Add("Test1");
            dt.Rows.Add("Test2");
            dt.Rows.Add("Test3");
            dt.Rows.Add("Test4");

            radGridView1.DataSource = dt;
            //radGridView1.datab
        }
    }
}
